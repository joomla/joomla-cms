
    *** In the Name of GOD ***

 My Apple Style Counter module for Joomla!

 @package    MyAppleStyleCounter.zip
 @subpackage Modules
 @link gpiutmd.iut.ac.ir
 @license GNU/GPL, see LICENSE.php
 My Apple Style Counter from GPIUTMD is a free software. This version
 may have been modified pursuant to the GNU General Public License, and 
 as distributed it includes or is derivative of works licensed under the
 GNU General Public License or other free or open source software licenses.

 This module is based on Nima Nouri's javascript skills

 
README for My Apple Style Counter for Joomla

A simple Apple Style module for counting the webpage visitors.
It is entirely Javascript and jQuery based so it
doesn't need Flash player. It has been tested and prooved to be OK with Joomla 1.6 and 1.5 .



INSTALLATION INSTRUCTIONS:
==========================

- download the MyAppleStyleCounter Module.
- install the Module using the Joomla Extensions install utility.
- ENABLE the new "My Apple Style Counter Module" within the Joomla 1.7, 1.6 or 1.5 backend Module manager.
- Remember to assign the module to the menus you want this module to be displayed on,
  (By default module is not assigned to any of the menu links).

Release Notes:
==============

- Version 1.6.5 (2011-11-25) The new jquery version added

- Version 1.6.4 (2011-10-19) The jquery bug reported on some machines are fixed

- Version 1.6.3 (2011-05-18) The animation problems are now fixed

- Version 1.6.2 (2011-05-12) The number images are now smoother

- Version 1.6.1 (2011-05-06) Corrected the year in the copyright disclaimer on the buttom of the module

- Version 1.6.0 (2011-04-24) Added the feature to use the Joomla MySQL database total hit number 

- Version 1.5.0 (2011-04-23) First GPL licensed Version

