<?php

if( !function_exists('inspect') ){
  function inspect(){
    echo '<pre>' . print_r(func_get_args(), true) . '</pre>';
  }
}

// fnmatch not available on non-POSIX systems
// Thanks to soywiz@php.net for this usefull alternative function [http://gr2.php.net/fnmatch]
if (!function_exists('fnmatch'))
{
  function fnmatch($pattern, $string)
  {
    return @preg_match(
      '/^' . strtr(addcslashes($pattern, '/\\.+^$(){}=!<>|'),
        array('*' => '.*', '?' => '.?')) . '$/i', $string
    );
  }
}

// Unicode-safe binary data length function
if (!function_exists('akstringlen'))
{
  if (function_exists('mb_strlen'))
  {
    function akstringlen($string)
    {
      return mb_strlen($string, '8bit');
    }
  }
  else
  {
    function akstringlen($string)
    {
      return strlen($string);
    }
  }
}

/**
 * Gets a query parameter from GET or POST data
 *
 * @param $key
 * @param $default
 */
function getQueryParam($key, $default = null)
{
  $value = $default;

  if (array_key_exists($key, $_REQUEST))
  {
    $value = $_REQUEST[$key];
  }

  if (get_magic_quotes_gpc() && !is_null($value))
  {
    $value = stripslashes($value);
  }

  return $value;
}

// Debugging function
function debugMsg($msg){
  if (!defined('KSDEBUG')){
    return;
  }
  $fp = fopen('debug.txt', 'at');
  fwrite($fp, (is_string($msg) ? $msg : print_r($msg,true)) . "\n");
  fclose($fp);
}
